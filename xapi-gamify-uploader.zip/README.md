# xAPI Gamify Uploader

MVP som lar deg laste opp Rise 360 xAPI zip-filer og kjøre dem med enkel server.

## Hvordan bruke
1. Installer Node.js (18+)
2. Kjør `npm install`
3. Start med `npm run dev`
4. Åpne http://localhost:8080 i nettleseren
5. Last opp en .zip fra Rise 360
6. Klikk linken til kurset for å starte
