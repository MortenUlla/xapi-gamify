const express = require('express');
const multer = require('multer');
const AdmZip = require('adm-zip');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 8080;

const upload = multer({ dest: 'uploads/' });

// Serve static courses
app.use('/courses', express.static(path.join(__dirname, 'courses')));

// Upload endpoint
app.post('/upload', upload.single('file'), (req, res) => {
  const filePath = req.file.path;
  const zip = new AdmZip(filePath);
  const courseName = path.basename(req.file.originalname, '.zip');
  const outputDir = path.join(__dirname, 'courses', courseName);

  // Extract course
  zip.extractAllTo(outputDir, true);

  // Modify tincan.xml if exists
  const tincanPath = path.join(outputDir, 'tincan.xml');
  if (fs.existsSync(tincanPath)) {
    let xml = fs.readFileSync(tincanPath, 'utf8');
    xml = xml.replace(/<endpoint>.*?<\/endpoint>/, '<endpoint>http://localhost:8080/xapi</endpoint>');
    fs.writeFileSync(tincanPath, xml);
  }

  fs.unlinkSync(filePath); // remove uploaded file

  res.send(`Upload successful! <a href="/courses/${courseName}/index.html">Open course</a>`);
});

// Dummy xAPI endpoint
app.post('/xapi', express.json(), (req, res) => {
  console.log("xAPI Statement:", req.body);
  res.status(200).send("OK");
});

// Simple upload form
app.get('/', (req, res) => {
  res.send(`
    <h1>Upload Rise xAPI ZIP</h1>
    <form ref='uploadForm' 
      id='uploadForm' 
      action='/upload' 
      method='post' 
      encType="multipart/form-data">
        <input type="file" name="file" />
        <input type='submit' value='Upload!' />
    </form>
  `);
});

app.listen(PORT, () => console.log("Server running on http://localhost:" + PORT));
